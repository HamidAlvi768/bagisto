<div class="justify-left flex gap-4 bg-neutral-100 pt-2 max-sm:hidden">
    <span class="shimmer block h-10 w-[141px] bg-gray-300"></span>

    <span class="shimmer block h-10 w-[70px] bg-gray-300"></span>

    <span class="shimmer block h-10 w-[101px] bg-gray-300"></span>

    <span class="shimmer block h-10 w-52 bg-gray-300"></span>
</div>